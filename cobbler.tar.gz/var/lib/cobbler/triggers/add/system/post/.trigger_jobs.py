#!/usr/bin/python
import sys, re
import sqlite3 as lite
from xmlrpclib import Server
from subprocess import Popen, PIPE
from email.mime.text import MIMEText

# Confluence settings
wikiRESTUrl = "https://singularity.jira.com/wiki/rpc/xmlrpc"
wikiuser = "wiki-robot"
wikipasswd = "testAPI123!"

# Confluence REST Initiation
s = Server(wikiRESTUrl)
token = s.confluence2.login(wikiuser, wikipasswd)

# SQLite connection object
conn = None

#########################################################################################################
#
# Name: connectToSQLite()
# Description: Connects to SQLite db else throws error and exits out off the script
# Returns: SQLite connection Object
#
def connectToSQLite():
	global conn

	try:
    		conn = lite.connect('/root/scripts/cobbler/cobbler.db')
	except lite.Error, e:
		msg = MIMEText("Error: "+e.args[0]+", system: "+str(sys.argv))
		msg["Subject"] = "Error - Trigger jobs DC2"
		msg["From"] = "ops@appdynamics.com"
		msg["To"] = "apallapothu@appdynamics.com"
		p = Popen(["/usr/sbin/sendmail", "-t"], stdin=PIPE)
		p.communicate(msg.as_string())
		sys.exit(1)

	return conn


conn = connectToSQLite()
cur = conn.cursor() # SQLite cursor

cur.execute("SELECT count(*) FROM trigger_jobs WHERE Status='new'")
newJobsCount = cur.fetchone()[0]

if newJobsCount == 1:
	# Update Wiki IP Manifest page
	wikipagealias = "IP Manifest DC2"
	page = s.confluence2.getPage(token, "OPS", wikipagealias)

	page["content"] = "<h3><span style='color:rgb(255,0,0);'> Contents in this page would be updated soon. As some system(s) are getting added/deleted/changed </span></h3>"
	s.confluence2.storePage(token, page)

	# Update Wiki Free available IP page
	wikipagealias = "Free available IPs on DC2"
	page = s.confluence2.getPage(token, "OPS", wikipagealias)

	page["content"] = "<h4><span style='color:rgb(255,0,0);'> Free Available IPs are being calculated, due to system being added/deleted/changed. Please wait for a while, till the page is reloaded. </span></h4>"
	s.confluence2.storePage(token, page)

    
# Update trigger jobs with the new entry	
if re.match( r'/var/lib/cobbler/triggers/(\w+)/system/post/', sys.argv[0], re.M|re.I):
	matchObj = re.match( r'/var/lib/cobbler/triggers/(\w+)/system/post/', sys.argv[0], re.M|re.I)
	operation = matchObj.group(1)	
	cur.execute("INSERT INTO trigger_jobs VALUES (NULL, ?, ?, 'new', datetime())", (operation, sys.argv[1]))
	conn.commit()

conn.close()
